var showState = "Variable";  // moved to the top (variable declaration)

function showState(){        // moved to the top (function declaration)
  console.log("Declaration");
}

console.log(showState);


// Do function or variable declarations get moved to the top?
// Which order?
