// What will be outputed?

var func = function() {
  console.log("Expresion");
};

function func() {
  console.log("Declaration");
}

func();

