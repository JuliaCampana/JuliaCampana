// So now what do you think will happen?

// EX 1

let x = 12;
console.log(x)

if (true) {
   let x = 50;
   console.log(x);
}


// EX 2
// What happens when we switch 'let' to 'var'?

// for (let i = 0; i <= 5; i++){
//     console.log(i);
// }
// console.log(i);
