// Which one will work or do they both work or do neither work?

funcDeclaration();

function funcDeclaration() {
  console.log("Ready");
}

funcExpression();

const funcExpression = function() {
  console.log("Expression");
};

