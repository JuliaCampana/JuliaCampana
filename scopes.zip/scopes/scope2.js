let locales = {
  europe: function() {          // The Europe continent's local scope
    let myFriend = "Monique";

    let france = function() {   // The France country's local scope
      let paris = function() {  // The Paris city's local scope
        console.log(myFriend);
      };

      paris();
    };

    france();
  }
};
locales.europe();
