// it never enters the if statement, so will it break?

// EX1
if (false){
    var x = 10;
}
console.log(x)

// EX2
console.log(y);
var y;

// EX3

console.log(z);
let z;

