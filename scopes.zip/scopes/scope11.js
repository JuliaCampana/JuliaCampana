// So what happens here?

function showName(){
  console.log(name);
}

showName();

let name = "James Dean";


