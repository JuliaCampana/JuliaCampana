// Are these any different?

// EX 1
var y = 50;
console.log(y)
var y;

// EX 2
let x = 50;
console.log(x)
let x;

